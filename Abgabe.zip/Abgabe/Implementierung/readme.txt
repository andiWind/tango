Erstellt mit Apache NetBeans IDE 12.0
Übersetzt mit Java 1.8.0_251
Es wurden keine zusätzlichen Bibliotheken eingebunden.
Der die maximale Größe des zur Ausführung verwendbaren Cache wurde mit der Option "Xmx4096m",
auf 4096 MB gesetzt.

 