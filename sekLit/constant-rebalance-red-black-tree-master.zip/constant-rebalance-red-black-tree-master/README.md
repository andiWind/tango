# constant-rebalance-red-black-tree
a red black tree that affords constant rebalancing once a node is inserted or deleted.
