package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import tango.RedBlackNode;

public class InstanceTests {

	@Test
	public void test() {

		@SuppressWarnings("unused")
		RedBlackNode n = new RedBlackNode(1, "1");

		assertTrue(true);
	}

}
